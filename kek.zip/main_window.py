from PyQt5.QtWidgets import QMainWindow, QShortcut
from PyQt5.QtGui import QKeySequence
from qt_designer import Ui_MainWindow


class MainWindow(QMainWindow, Ui_MainWindow):
    
    def __init__(self):
        
        super().__init__()
        
        self.setupUi(self)
        self.setFixedWidth(self.width())
        self.setFixedHeight(self.height())
        self.close_shortcut = QShortcut(QKeySequence("Ctrl+w"), self)
        self.close_shortcut.activated.connect(self.close)
    
    
        
    def closeEvent(self, event):
        print("== APP SUCCESSFULLY CLOSED ==")
        event.accept()