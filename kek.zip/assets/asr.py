import requests

def asr(api_key, user_id, input_lang, base64_input, audio_format, sampling_rate):

    url_config = "https://meity-auth.ulcacontrib.org/ulca/apis/v0/model/getModelsPipeline"
    
    headers_config = {
        "Content-Type": "application/json",
        "ulcaApiKey": api_key,
        "userID": user_id
    }

    payload_config = {
        "pipelineTasks": [
            {
                "taskType": "asr",
                "config": {
                    "language": {
                        "sourceLanguage": input_lang
                    }
                }
            }
        ],
        "pipelineRequestConfig": {
            "pipelineId": "64392f96daac500b55c543cd"
        }
    }

    response = requests.post(url_config, json=payload_config, headers=headers_config)

    if response.status_code == 200:
        response_data = response.json()
        print("Success:", response_data)
    else:
        print("Error:", response.status_code, response.text)
        return None  # Early exit if there's an error

    compute_url = response_data['pipelineInferenceAPIEndPoint']['callbackUrl']
    header_name = response_data['pipelineInferenceAPIEndPoint']['inferenceApiKey']['name']
    header_value = response_data['pipelineInferenceAPIEndPoint']['inferenceApiKey']['value']
    payload_serviceID = response_data['pipelineResponseConfig'][0]['config'][0]['serviceId']
    payload_modelId = response_data['pipelineResponseConfig'][0]['config'][0]['modelId']

    url_compute = compute_url
    null = "null"

    headers_compute = {
        header_name: header_value
    }

    payload_compute = {
        "pipelineTasks": [
            {
                "taskType": "asr",
                "config": {
                    "language": {
                        "sourceLanguage": input_lang
                    },
                    "serviceId": payload_serviceID,
                    "audioFormat": audio_format,
                    "samplingRate": sampling_rate
                }
            }
        ],
        "inputData": {
            "input": [
                {
                    "source": null
                }
            ],
            "audio": [
                {
                    "audioContent": base64_input
                }
            ]
        }
    }

    response = requests.post(url_compute, json=payload_compute, headers=headers_compute)

    if response.status_code == 200:
        asr = response.json()
        print("Translated text:", asr)
    else:
        print("Error:", response.status_code, response.text)
        return None  # Early exit if there's an error

    # Check if the expected keys exist before accessing them
    if 'pipelineResponse' in asr and len(asr['pipelineResponse']) > 0 and 'output' in asr['pipelineResponse'][0]:
        print("kek")
        asr_output = asr['pipelineResponse'][0]['output'][0]['source']
        return asr_output
    else:
        print("Unexpected response format:", asr)
        return None
