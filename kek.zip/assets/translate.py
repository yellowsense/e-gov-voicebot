import sys
import requests
import json


def translation(api_key, user_id, input_lang, output_lang, text):
    url_config = "https://meity-auth.ulcacontrib.org/ulca/apis/v0/model/getModelsPipeline"

    headers_config = {
        "Content-Type": "application/json",
        "ulcaApiKey": api_key,
        "userID": user_id
    }

    payload_config = {
        "pipelineTasks": [{
            "taskType": "translation",
            "config": {
                "language": {
                    "sourceLanguage": input_lang,
                    "targetLanguage": output_lang
                }
            }
        }],
        "pipelineRequestConfig": {
            "pipelineId": "64392f96daac500b55c543cd"
        }
    }

    response = requests.post(url_config, json=payload_config, headers=headers_config)

    if response.status_code != 200:
        print("Error:", response.status_code, response.text)
        return None

    response_data = response.json()

    compute_url = response_data['pipelineInferenceAPIEndPoint']['callbackUrl']
    header_name = response_data['pipelineInferenceAPIEndPoint']['inferenceApiKey']['name']
    header_value = response_data['pipelineInferenceAPIEndPoint']['inferenceApiKey']['value']
    payload_serviceID = response_data['pipelineResponseConfig'][0]['config'][0]['serviceId']
    payload_modelId = response_data['pipelineResponseConfig'][0]['config'][0]['modelId']

    headers_compute = {
        header_name: header_value
    }

    payload_compute = {
        "pipelineTasks": [
            {
                "taskType": "translation",
                "config": {
                    "language": {
                        "sourceLanguage": input_lang,
                        "targetLanguage": output_lang
                    },
                    "serviceId": payload_serviceID,
                    "modelId": payload_modelId
                }
            }
        ],
        "inputData": {
            "input": [
                {
                    "source": text
                }
            ]
        }
    }

    response = requests.post(compute_url, json=payload_compute, headers=headers_compute)

    if response.status_code != 200:
        print("Error:", response.status_code, response.text)
        return None

    translated_text = response.json()
    output_text = translated_text['pipelineResponse'][0]['output'][0]['target']
    
    return output_text