import base64


def wav_to_base64(file_path):
    
    with open(file_path, 'rb') as wav_file:
        wav_data = wav_file.read()
        base64_encoded = base64.b64encode(wav_data)
        base64_string = base64_encoded.decode('utf-8')
    
    return base64_string
